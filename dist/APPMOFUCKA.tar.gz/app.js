require('coffee-script')
server = require("./server");
config = require("./foo");
server.startServer(config);